# MyCartDemo
android自定义柱状图
###look at the screenshot:

<img src="http://img.blog.csdn.net/20161220225449350?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvbHloaGo=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast" width = "320" height = "640" alt="高仿微信群聊头像" align=center />
