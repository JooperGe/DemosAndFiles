package com.hankkin.mycartdemo;

/**
 * Created by Hankkin on 16/12/11.
 * 邮箱
 */

public class MyBean {
    private String name;
    private int number;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
